+ ZIP support via libarchive.
